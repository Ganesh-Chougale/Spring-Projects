package com.verligence.PLISM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlismApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlismApplication.class, args);
	}

}
